aws ecr get-login --no-include-email --region eu-central-1

docker build -t trivadis/ffmpeg .

docker tag trivadis/ffmpeg:latest 663559919114.dkr.ecr.eu-central-1.amazonaws.com/trivadis/ffmpeg:latest

docker push 663559919114.dkr.ecr.eu-central-1.amazonaws.com/trivadis/ffmpeg:latest